# Concurrent Banking System
## CL2006 – Operating System Lab | Spring 2026 | FAST-NUCES

---

## 1. Introduction

This project implements a **Concurrent Banking System** that demonstrates five core Operating System concepts: CPU Scheduling, Process Synchronization, Deadlock Avoidance, Inter-Process Communication (IPC), and Memory Management. The system simulates a bank with multiple customer types — Regular, Premium, Loan Applicant, Corporate, and VIP — each interacting concurrently with shared resources.

All modules produce measurable output including Gantt charts, scheduling metrics, Banker's Algorithm traces, IPC request/response logs, and page replacement comparisons.

---

## 2. System Architecture

```
banking_system
├── main.c          – Entry point, module orchestration
├── accounts.c      – Account management with mutex/semaphore protection
├── scheduling.c    – FCFS, Priority, Round Robin schedulers + Gantt charts
├── sync.c          – Thread synchronization demos (mutex + semaphore)
├── banker.c        – Banker's Algorithm for deadlock avoidance
├── ipc.c           – POSIX message queues, producer-consumer pattern
├── memory.c        – FIFO and LRU page replacement algorithms
└── utils.c         – Logging and shared utilities
```

---

## 3. Customer Types

| Type | Priority | Description |
|---|---|---|
| Regular | 1 | Standard deposits/withdrawals |
| Loan Applicant | 2 | Requests checked via Banker's Algorithm |
| Premium | 3 | Higher scheduling priority |
| Corporate | 4 | Multiple payroll threads |
| VIP | 5 | Highest priority, preempts others |

---

## 4. Module 1 – CPU Scheduling

### Overview
Each customer request is modeled as a process with an arrival time, burst time (processing duration), and priority equal to their customer type.

### Algorithms Implemented
- **FCFS (First Come First Served):** Processes sorted by arrival time. Non-preemptive.
- **Priority Scheduling:** Processes sorted by priority (VIP=5 first). Non-preemptive.
- **Round Robin (RR):** Time quantum = 2 ms. Each process gets equal CPU slices, cycling until completion.

### Test Data

| Customer | Type | Priority | Arrival (ms) | Burst (ms) |
|---|---|---|---|---|
| Alice | Regular | 1 | 0 | 8 |
| Acme | Corporate | 4 | 1 | 6 |
| Bob | Premium | 3 | 2 | 5 |
| Diana | VIP | 5 | 3 | 4 |
| Charlie | Loan | 2 | 4 | 3 |
| Eve | Regular | 1 | 5 | 7 |

### Results

**FCFS Gantt Chart:**
```
| Alice  | Acme   | Bob    | Diana  | Charlie | Eve    |
0        8        14       19       23        26       33
```
Avg Waiting: 12.50 ms | Avg Turnaround: 18.00 ms

**Priority Scheduling Gantt Chart:**
```
| Diana  | Acme   | Bob    | Charlie | Alice  | Eve    |
3        7        13       18        21       29       36
```
Avg Waiting: 12.67 ms | Avg Turnaround: 18.17 ms

Note: VIP (Diana, priority 5) executes first; Regular customers (Alice, Eve) last.

**Round Robin Gantt Chart (quantum=2):**
```
| A | B | C | Ac | D | E | A | B | C | Ac | D | E | A | B | Ac | E | A | E |
0   2   4   6    8   10  12  14  16  17   19  21  23  25  26   28  30  32  33
```
Avg Waiting: 18.17 ms | Avg Turnaround: 23.67 ms

Note: Round Robin gives all processes equal CPU time, so VIP customers experience higher waiting time but the system is fairer.

### Comparison

| Algorithm | Avg Waiting (ms) | Avg Turnaround (ms) | Best For |
|---|---|---|---|
| FCFS | 12.50 | 18.00 | Simple batch processing |
| Priority | 12.67 | 18.17 | VIP/Premium first service |
| Round Robin | 18.17 | 23.67 | Fairness, time-sharing |

---

## 5. Module 2 – Synchronization

### Overview
Shared account balances are protected using two mechanisms:
- **Mutex Lock (`pthread_mutex_t`):** Ensures mutual exclusion during balance updates. Only one thread can modify an account balance at a time, preventing race conditions.
- **Semaphore (`sem_t`):** Initialized to 2, allowing at most 2 concurrent deposits. A third deposit blocks until one completes.

### Test Cases

**Test 1 – Mutex: Concurrent Withdrawals**
- Two threads (Alice-T1: -1000, Alice-T2: -500) attempt withdrawal from Account 1001 simultaneously.
- Mutex ensures sequential execution. Final balance: 3500.00 (correct).
- Without mutex: both might read the same balance → race condition → wrong result.

**Test 2 – Semaphore: Three Concurrent Deposits**
- Three threads attempt deposits to Account 1002.
- Semaphore(2) allows Bob-D1 and Bob-D2 through immediately; Charlie-D1 blocks until a slot frees.
- Result: All three deposits complete correctly without corruption.

**Test 3 – Corporate Payroll**
- Acme Corp spawns 10 payroll threads, each depositing 500.00 to Account 1004.
- Mutex ensures all 10 updates are atomic. Final balance: 20000.00 (correct).

**Test 4 – VIP Priority**
- Diana (VIP) withdrawal executes before Eve (Regular) deposit, demonstrating priority-based thread execution.

---

## 6. Module 3 – Deadlock Avoidance (Banker's Algorithm)

### Overview
Loan requests are modeled as resource allocation requests. Resources represent: [Credit Units, Tellers, Vault Access]. The Banker's Algorithm evaluates each request: if granting it could lead to a deadlock (unsafe state), it is denied.

### Initial State

| Customer | Allocation | Max Need | Current Need |
|---|---|---|---|
| Alice (P0) | [0,1,0] | [7,5,3] | [7,4,3] |
| Bob (P1) | [2,0,0] | [3,2,2] | [1,2,2] |
| Charlie (P2) | [3,0,2] | [9,0,2] | [6,0,0] |
| Acme (P3) | [2,1,1] | [2,2,2] | [0,1,1] |
| Diana (P4) | [0,0,2] | [4,3,3] | [4,3,1] |

Available: [3,3,2]

Initial Safe Sequence: **P1 → P3 → P4 → P0 → P2**

### Test Cases

| Test | Customer | Request | Decision | Reason |
|---|---|---|---|---|
| 1 | Bob (P1) | [1,0,2] | **APPROVED** | System remains safe |
| 2 | Charlie (P2) | [3,3,0] | **DENIED** | Exceeds max need |
| 3 | Alice (P0) | [9,9,9] | **DENIED** | Exceeds max need |
| 4 | Diana (P4) | [2,1,0] | **APPROVED** | System remains safe |

### Safety Algorithm
After each tentative allocation, the safety algorithm finds a safe execution sequence. If no such sequence exists, the allocation is rolled back.

---

## 7. Module 4 – IPC (Message Queues)

### Overview
Customer processes communicate with a bank server process using **POSIX System V Message Queues**. This implements the **Producer-Consumer** pattern: customers (producers) send transaction requests; the bank server (consumer) processes them one by one.

### Architecture
```
Customer Process 1 ──┐
Customer Process 2 ──┤
Customer Process 3 ──┼──► [Message Queue] ──► Bank Server Process
Customer Process 4 ──┤                              │
Customer Process 5 ──┘                         Sends response
                                                back via queue
```

### Message Flow
1. Customer process sends: `{account_id, transaction_type, amount}`
2. Bank server reads from queue, processes transaction, updates balance.
3. Server sends response: `{success, new_balance, message}`
4. Customer reads response and logs result.

### Test Transactions

| Customer | Account | Transaction | Amount |
|---|---|---|---|
| Alice | 1001 | Deposit | 500.00 |
| Bob | 1002 | Withdrawal | 200.00 |
| Charlie | 1003 | Deposit | 1000.00 |
| Acme Corp | 1004 | Deposit | 3000.00 |
| Diana | 1005 | Withdrawal | 5000.00 |

All requests are processed sequentially by the bank server with full request/response logging.

---

## 8. Module 5 – Memory Management

### Overview
Each customer's account data and transaction history is represented as memory pages. When the frame buffer is full and a new page is needed, a page replacement algorithm evicts an existing page.

### Page Reference String
`1 → 2 → 3 → 4 → 1 → 2 → 5 → 1 → 2 → 3 → 4 → 5 → 3 → 2 → 1 → 4 → 5 → 2 → 3 → 1`

(20 page references, 5 distinct pages: accounts for Alice, Bob, Charlie, Acme, Diana)

### Algorithms

**FIFO (First In First Out):** Evicts the page that has been in memory the longest (oldest loaded page).

**LRU (Least Recently Used):** Evicts the page that was used least recently (tracks last-access timestamp).

### Results (3 Frames)

| Metric | FIFO | LRU |
|---|---|---|
| Page Faults | 14 | 12 |
| Page Hits | 6 | 8 |
| Hit Ratio | 30.0% | 40.0% |
| Fault Rate | 70.0% | 60.0% |

**Conclusion:** LRU outperforms FIFO with this reference string (fewer faults, higher hit ratio), because FIFO can evict recently-used pages (Belady's anomaly) while LRU keeps the most recently accessed pages.

---

## 9. How to Compile and Run

```bash
# Compile
make

# Run
./banking_system

# View log
cat logs/banking_system.log

# Clean
make clean
```

**Requirements:** GCC with POSIX thread support (`-pthread`), Linux OS (Ubuntu/Debian recommended).

---

## 10. Key OS Concepts Demonstrated

| Concept | Implementation | File |
|---|---|---|
| Threads | `pthread_create`, `pthread_join` | sync.c, ipc.c |
| Mutex Locks | `pthread_mutex_lock/unlock` | accounts.c |
| Semaphores | `sem_init`, `sem_wait`, `sem_post` | accounts.c |
| Scheduling | FCFS, Priority, Round Robin | scheduling.c |
| Banker's Algorithm | Safety + Resource-Request | banker.c |
| Message Queues | `msgget`, `msgsnd`, `msgrcv` | ipc.c |
| Fork/Processes | `fork`, `waitpid` | ipc.c |
| Page Replacement | FIFO, LRU | memory.c |

---

*FAST-NUCES Chiniot-Faisalabad Campus | CL2006 OS Lab | Spring 2026*
