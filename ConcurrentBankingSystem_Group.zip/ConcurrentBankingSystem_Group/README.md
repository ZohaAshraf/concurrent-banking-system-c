# Concurrent Banking System
### CL2006 – Operating System Lab | Spring 2026 | FAST-NUCES

A complete simulation of a concurrent banking system demonstrating five OS concepts.

---

## Quick Start

```bash
make        # compile
make run    # compile and run
make clean  # remove binary and logs
```

## Modules

| # | Module | Concepts |
|---|---|---|
| 1 | CPU Scheduling | FCFS, Priority Scheduling, Round Robin, Gantt Charts |
| 2 | Synchronization | Mutex Locks, Semaphores, Multithreading |
| 3 | Deadlock Avoidance | Banker's Algorithm, Safety Algorithm |
| 4 | IPC | POSIX Message Queues, Fork, Producer-Consumer |
| 5 | Memory Management | FIFO Page Replacement, LRU Page Replacement |

## Directory Structure

```
ConcurrentBankingSystem_Group/
├── src/
│   ├── banking.h       – Shared types, constants, prototypes
│   ├── main.c          – Entry point
│   ├── accounts.c      – Account management + mutex/semaphore
│   ├── scheduling.c    – FCFS, Priority, Round Robin
│   ├── sync.c          – Thread synchronization demo
│   ├── banker.c        – Banker's Algorithm
│   ├── ipc.c           – Message queues + processes
│   ├── memory.c        – Page replacement
│   └── utils.c         – Logging utilities
├── logs/               – Runtime log output
├── report/
│   └── Report.md       – Full project report
└── Makefile
```

## Requirements

- Linux (Ubuntu 24 recommended)
- GCC 9+
- POSIX thread and IPC support (standard on Linux)
